import UIKit

struct CarChoices {
    var engine1 = Int(4)
    var engine2 = Int (6)

    init(engine1:Int ) {
        self.engine1 = engine1
    }
}
var aStruct = CarChoices(engine1:4)
var bStruct = aStruct
bStruct.engine2 = 4

var AStruct = CarChoices(engine1:6)
var BStruct = aStruct
BStruct.engine2 = 6
 print("The most common engine found in a car is the V\(aStruct.engine1) engine")
 print("Zooming through the streets with the V\(bStruct.engine2) engine!")
